<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ongeza_test";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT id,gender_name FROM gender";
$result = $conn->query($sql);

    echo "<html>";
    echo "<body>";
    echo "<select gender_name='id'>";
  
    while ($row = $result->fetch_assoc()) {

                  unset($id, $name);
                  $id = $row['id'];
                  $name = $row['gender_name']; 
                  echo '<option value="'.$id.'">'.$name.'</option>';

}

    echo "</select>";
    echo "</body>";
    echo "</html>";
?>