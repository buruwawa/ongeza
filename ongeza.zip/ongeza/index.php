<html>
<head>
<title>Ongeza Online Test</title>
<link href="css/insert.css" rel="stylesheet">
<link href="css/table.css" rel="stylesheet">
</head>
<body>
<div class="maindiv">
<!--HTML Form -->
<h2>Ongeza Online Test</h2>
<div class="row">
           <nav>
              <ol class="breadcrumb">
                <li class=""><a href="read_customer.php">Register and reading data in Customer table</a></li>
                 <li class=""><a href="select_update.php">Updating and deleting Customer table</a></li>				  
              </ol>			   
            </nav>
</div>
</body>
</html>
       