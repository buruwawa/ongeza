<?php

//$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
//$db = mysql_select_db("ongeza_test", $connection); // Selecting Database from Server

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ongeza_test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
    $first_name = $_POST['first_name'];
	 $last_name = $_POST['last_name'];
	 $town_name = $_POST['town_name'];
	 // $id = $_POST['info'];
	  
	 	 $sql = "INSERT INTO customer(first_name,last_name,town_name)
	 VALUES ('$first_name','$last_name','$town_name')";
	 if (mysqli_query($conn, $sql)) {
		echo "New record created successfully  in customer table!";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
//mysql_close($conn); // Closing Connection with Server
?>