<?php

//$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
//$db = mysql_select_db("ongeza_test", $connection); // Selecting Database from Server

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ongeza_test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
       $gender_name = $_POST['gender_name'];
	
	 	 $sql = "INSERT INTO gender(gender_name)  VALUES('$gender_name')";
	       
	 if (mysqli_query($conn, $sql)) {
		echo "New record created successfully in gender table!";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>