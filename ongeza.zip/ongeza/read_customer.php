<html>
<head>
<title>Ongeza Online Test</title>
<link href="css/insert.css" rel="stylesheet">
<link href="css/table.css" rel="stylesheet">
</head>
<body>
<div class="maindiv">
<!--HTML Form -->
<div class="row">
<div class="form_div">
<!--<div class="title">
<h2>Insert Data In Database Using PHP.</h2>
</div> -->

<form action="insert_gender.php" method="post">
<!-- Method can be set as POST for hiding values in URL-->
<h2>Insert data into Gender table:</h2> <label>Gender name:</label>
<input class="input" name="gender_name" type="text" value="">
<input class="submit" name="submit" type="submit" value="Insert">
</form>

<form action="insert_customer.php" method="post">
<!-- Method can be set as POST for hiding values in URL-->
<h2>Insert data into Customer table:</h2>
<label>First name:</label>
<input class="input" name="first_name" type="text" value="">
<label>Last name:</label>
<input class="input" name="last_name" type="text" value="">
	<hr>
<!-- Gender part -->
 <label>Gender:</label>
 
 <div id = "info">   
     <?php
     include('gender.php');
     ?>	
    </div>

	<hr>
<label>Town:</label>
<input class="input" name="town_name" type="text" value="">
<!--<label>Address:</label>
<textarea cols="25" name="address" rows="5"></textarea><br> -->
<input class="submit" name="submit" type="submit" value="Save">
</form>
</div>
<div>


<h2>Result table Data</h2>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ongeza_test";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT id, first_name, last_name,town_name,gender_id FROM customer";
$result = $conn->query($sql);
 
echo "<table class='responstable' border='1'>
<tr>
<th>Id</th>
<th>First name</th>
<th>Last name</th>
<th>Town</th>
</tr>";
 
while($row = mysqli_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['id'] . "</td>";
  echo "<td>" . $row['first_name'] . "</td>";
  echo "<td>" . $row['last_name'] . "</td>";
   echo "<td>" . $row['town_name'] . "</td>";
  // echo "<td>" . $row['gender_id'] . "</td>";
  echo "</tr>";
  }
echo "</table>";
 
mysqli_close($conn);
?>
<hr>
</div>
</div>
</body>
</html>
       