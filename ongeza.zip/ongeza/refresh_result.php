<h2>Result table Data</h2>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ongeza_test";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT id, first_name, last_name,town_name,gender_id FROM customer";
$result = $conn->query($sql);
 
echo "<table class='responstable' border='1'>
<tr>
<th>Id</th>
<th>First name</th>
<th>Last name</th>
<th>Town</th>
</tr>";
 
while($row = mysqli_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['id'] . "</td>";
  echo "<td>" . $row['first_name'] . "</td>";
  echo "<td>" . $row['last_name'] . "</td>";
   echo "<td>" . $row['town_name'] . "</td>";
  // echo "<td>" . $row['gender_id'] . "</td>";
  echo "</tr>";
  }
echo "</table>";
 
mysqli_close($conn);
?>