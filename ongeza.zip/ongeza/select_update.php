<?php

extract($_POST);

//do addition and store the result in $res
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ongeza_test";

$id="";
$fname="";
$lname="";
$town="";

if(isset($search))
{

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT id,first_name,last_name,town_name FROM customer where id='$idno'";
$result = $conn->query($sql);
					  
   while ($row = $result->fetch_assoc()) {
                  // unset($id, $name);
				  $id = $row['id'];
                  $fname = $row['first_name'];
				  $lname = $row['last_name'];
				  $town = $row['town_name'];
   }
   $conn->close();
}

//do subtraction and store the result in $res
if(isset($update))
{
	$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
        $id = $_POST['id'];
     $first_name = $_POST['fname'];
	 $last_name = $_POST['lname'];
	 $town_name = $_POST['town'];
	 // $id = $_POST['info'];
	  
	 	 $sql = "update customer set first_name='$first_name',last_name='$last_name',town_name='$town_name' where id='$id'";
	 if (mysqli_query($conn, $sql)) {
		echo "New record updated successfully  in customer table!";
	 } else {
		echo "Error: " . $sql . "
 " . mysqli_error($conn);
	 }
	 mysqli_close($conn);	 
	}	

//do multiplicatio and store the result in $res
if(isset($delete))
{

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "delete FROM customer where id='$id'";
$result = $conn->query($sql);			  
   
   $conn->close();
}	
 
?>
 
<html>

<head>

	<title>Display the result in 3rd text box</title>

	</head>

	<body>
	<div class="row">
	<div>
<form method="POST">

 <table align="center" border="2">
 
	<tr>	
<th></th>	
		<td>
		<h2>Update and delete in Customer table</h2>
		</td>
		
	</tr>
	
	<tr>
	
		<th>Search</th>		
		<td colspan="1"><input type="text" name="idno"/>
		<input type="submit" value="Search" name="search"/>
		</td>		
	</tr>	
	
	<tr>
	
		<th>ID:</th>		
		<td><input type="text" value="<?php echo $id;?>" name="id" placeholder="id"/></td>
		
	</tr>
	<tr>
	
		<th>First name:</th>		
		<td><input type="text" value="<?php echo $fname;?>" name="fname" placeholder="first name"/></td>
		
	</tr>
	<tr>
	
		<th>Last name:</th>		
		<td><input type="text" value="<?php echo $lname;?>" name="lname" placeholder="last name"/></td>
		
	</tr>
	<tr>
	
		<th>Town:</th>		
		<td><input type="text" value="<?php echo $town;?>" name="town" placeholder="town name"/></td>
		
	</tr>
	<Tr>
		
	</tr>
	<tr>
	
		  <td align="center" colspan="2">
		<!--<input type="submit" value="Search" name="search"/> -->
			<input type="submit" value="Update" name="update"/>	
		<input type="submit" value="Delete" name="delete"/>
		
	</tr>	
	</table>		
</form>
</div>
<div align="center">

<h2>Result table Data from customer table</h2>
<?php

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT id, first_name, last_name,town_name,gender_id FROM customer";
$result = $conn->query($sql);
 
echo "<table class='responstable' border='1'>
<tr>
<th>Id</th>
<th>First name</th>
<th>Last name</th>
<th>Town</th>
</tr>";
 
while($row = mysqli_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['id'] . "</td>";
  echo "<td>" . $row['first_name'] . "</td>";
  echo "<td>" . $row['last_name'] . "</td>";
   echo "<td>" . $row['town_name'] . "</td>";
  // echo "<td>" . $row['gender_id'] . "</td>";
  echo "</tr>";
  }
echo "</table>";
 
mysqli_close($conn);
?>
</div>
</div>
</body>
</html>